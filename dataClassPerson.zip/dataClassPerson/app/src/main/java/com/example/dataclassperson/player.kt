package com.example.dataclassperson

data class player(var name:String, var age:Int, var height:Int)
