 package com.example.dataclassperson

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    lateinit var sortedAge : List<player>
    lateinit var sortedName:List<player>
    lateinit var sortedHeight:List<player>
    lateinit var players :List<player>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
         players = listOf(
            player("Atheer", 23, 160),
            player("saleh", 24, 180),
            player("moh", 23, 170),
            player("sara", 23, 156),
            player("sami", 25, 160),
            player("ahmed", 23, 170),
            player("norah", 36, 165),
            player("saleh", 24, 180),
            player("moh", 23, 170),
            player("sara", 23, 156),
            player("sami", 25, 160),
            player("ahmed", 23, 170),
            player("norah", 36, 165),
            player("norah", 36, 165),
            player("saleh", 24, 180),
            player("moh", 23, 170),
            player("sara", 23, 156),
            player("sami", 25, 160),
            player("ahmed", 23, 170),
            player("norah", 36, 165)
)
        sortplayer()
        println("sorted by age \n" + sortedAge)
        println("sorted by name \n" + sortedName)
        println("sorted by height \n" + sortedHeight)



    }
    var sortplayer={
        sortedAge=players.sortedBy { it.age }
        sortedName=players.sortedBy { it.name }
        sortedHeight=players.sortedBy { it.height }

    }

}