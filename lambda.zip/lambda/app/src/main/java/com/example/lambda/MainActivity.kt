package com.example.lambda

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var b:TextView
        b=findViewById(R.id.tv)
        var d=resize(4,b)
        println(d )

    }


    //lambda
    //1
    var p = { println("Atheer") }
//    p()

    //2
    // var PlusMin={text:String ->
//
//    var num= mytext.text.toString();
//    var num1:Int=num.toInt();
//    if("+" == text ){
//        num1++
//        mytext.text= num1.toString()
//
//    }else{
//        num1--
//        mytext.text= num1.toString()
//
//
//    }
//    if(num1<0){
//        mytext.setTextColor(Color.RED)
//
//    }
//    else if(num1>0){
//        mytext.setTextColor(Color.GREEN)
//
//    }else{
//        mytext.setTextColor(Color.BLACK)
//
//    }
//
    //3
    var Meow={ name:String -> println("name of cat:" + name)
      println(name+":Meow")}

   //4
   var resize={num:Int ,tvId: TextView ->


       tvId.textSize=num.toFloat()

    "resize done"}
    //5
    var remainder={num1: Int, num2: Int ->
         (num1 % num2)
    }





    // -------------------------------------------------------------
    //orginals
    //1
    fun p() {println("Atheer") }
    //2
    // fun PlusMin(text:String){
//
//    var num= mytext.text.toString();
//    var num1:Int=num.toInt();
//    if("+" == text ){
//        num1++
//        mytext.text= num1.toString()
//
//    }else{
//        num1--
//        mytext.text= num1.toString()
//
//
//    }
//    if(num1<0){
//        mytext.setTextColor(Color.RED)
//
//    }
//    else if(num1>0){
//        mytext.setTextColor(Color.GREEN)
//
//    }else{
//        mytext.setTextColor(Color.BLACK)
//
//    }

    //3
fun Meow( name:String){ println("name of cat:" + name)
        println(name+":Meow")}


    //4
fun resize(num:Int ,tvId: TextView ):String {

    tvId.textSize = num.toFloat()

    return "resize done"
}
    //5
    fun remainder(num1: Int, num2: Int): Int {
        return (num1 % num2);
    }

}